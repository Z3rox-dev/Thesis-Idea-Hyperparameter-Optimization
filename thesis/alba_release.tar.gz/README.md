# ALBA Framework

**ALBA** (Adaptive Local Bayesian Algorithm) per Hyperparameter Optimization.

Vedere `INSTALL.md` per istruzioni dettagliate.

## Installazione rapida

```bash
pip install .
```

## Demo

```bash
python -m alba_framework_potential.examples.quick_demo
```
